
import java.util.StringTokenizer;

public class ArbolExpresiones {
    Pila pOperandos;               // Pila de operandos
    Pila pOperadores;              // Pila de operadores
    final String blanco;           // Cadena de espacios en blanco
    final String operadores;       // Cadena con operadores para expresiones

    /**
     * Constructor por omisión
     */
    public ArbolExpresiones() {
        pOperandos = new Pila();
        pOperadores = new Pila();
        blanco = " \t";
        operadores = "()+-*/%^";  // Operadores válidos
    }

    /**
     * Método para construir un árbol para una expresión aritmética dada.
     * @param expresion -- Cadena con la expresión aritmética
     * @return NodoArbol -- nodo raíz del árbol creado
     */
    public NodoArbol construirArbol(String expresion) {
        StringTokenizer tokenizer;
        String token;
        NodoArbol raiz = null;

        tokenizer = new StringTokenizer(expresion, blanco + operadores, true);
        while (tokenizer.hasMoreTokens()) {
            token = tokenizer.nextToken();
            if (blanco.indexOf(token) >= 0) {
                // Es un espacio en blanco, se ignora
                continue;
            } else if (operadores.indexOf(token) < 0) {
                // Es operando y lo guarda como nodo del árbol
                pOperandos.push(new NodoArbol(token));
            } else if (token.equals(")")) {
                // Saca elementos hasta encontrar (
                while (!pOperadores.estaVacia() && !pOperadores.top().equals("(")) {
                    guardarSubArbol();
                }
                pOperadores.pop();  // Saca el paréntesis izquierdo
            } else {
                if (!token.equals("(") && !pOperadores.estaVacia()) {
                    // Operador diferente de cualquier paréntesis
                    String op = (String) pOperadores.top();
                    while (!op.equals("(") && !pOperadores.estaVacia() 
                           && operadores.indexOf(op) >= operadores.indexOf(token)) {
                        guardarSubArbol();
                        if (!pOperadores.estaVacia()) 
                            op = (String) pOperadores.top();
                    }
                }
                pOperadores.push(token);  // Guarda el operador
            }
        }
        // Sacar todo lo que queda
        raiz = (NodoArbol) pOperandos.top();
        while (!pOperadores.estaVacia()) {
            if (pOperadores.top().equals("(")) {
                pOperadores.pop();
            } else {
                guardarSubArbol();
                raiz = (NodoArbol) pOperandos.top();
            }
        }
        return raiz;
    }

    /*
     * Método privado para almacenar en la pila un subárbol
     */
    private void guardarSubArbol() {
        NodoArbol op2 = (NodoArbol) pOperandos.pop();
        NodoArbol op1 = (NodoArbol) pOperandos.pop();
        pOperandos.push(new NodoArbol(op1, pOperadores.pop(), op2));
    }

    /**
     * Método para imprimir un árbol en inorden
     * @param n -- nodo raíz
     */
    public String imprime(NodoArbol n) {
        StringBuilder sb = new StringBuilder();
        imprime(n, sb);
        return sb.toString();
    }

    private void imprime(NodoArbol n, StringBuilder sb) {
        if (n != null) {
            imprime(n.izquierda, sb);
            sb.append(n.valor + " ");
            imprime(n.derecha, sb);
        }
    }

    /**
     * Método para imprimir un árbol en postorden
     * @param n -- nodo raíz
     */
    public String imprimePos(NodoArbol n) {
        StringBuilder sb = new StringBuilder();
        imprimePos(n, sb);
        return sb.toString();
    }

    private void imprimePos(NodoArbol n, StringBuilder sb) {
        if (n != null) {
            imprimePos(n.izquierda, sb);
            imprimePos(n.derecha, sb);
            sb.append(n.valor + " ");
        }
    }

    /**
     * Método para imprimir un árbol en preorden
     * @param n -- nodo raíz
     */
    public String imprimePre(NodoArbol n) {
        StringBuilder sb = new StringBuilder();
        imprimePre(n, sb);
        return sb.toString();
    }

    private void imprimePre(NodoArbol n, StringBuilder sb) {
        if (n != null) {
            sb.append(n.valor + " ");
            imprimePre(n.izquierda, sb);
            imprimePre(n.derecha, sb);
        }
    }
}

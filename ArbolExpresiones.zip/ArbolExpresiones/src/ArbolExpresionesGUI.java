import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ArbolExpresionesGUI extends JFrame {
    private JTextArea expressionArea;
    private JTextArea resultArea;
    private ArbolExpresiones arbolExpresiones;

    public ArbolExpresionesGUI() {
        arbolExpresiones = new ArbolExpresiones();

        setTitle("Árbol de Expresiones");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Crear el área de texto para la entrada de expresiones
        expressionArea = new JTextArea(3, 30);
        JScrollPane expressionScrollPane = new JScrollPane(expressionArea);

        // Crear el botón de evaluar
        JButton evaluateButton = new JButton("Evaluar");
        evaluateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evaluarExpresion();
            }
        });

        // Crear el área de texto para mostrar los resultados
        resultArea = new JTextArea(10, 30);
        resultArea.setEditable(false);
        JScrollPane resultScrollPane = new JScrollPane(resultArea);

        // Crear paneles para organizar los componentes
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new BorderLayout());
        inputPanel.add(new JLabel("Ingrese la expresión aritmética:"), BorderLayout.NORTH);
        inputPanel.add(expressionScrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(evaluateButton);

        // Configurar el diseño del JFrame
        setLayout(new BorderLayout());
        add(inputPanel, BorderLayout.NORTH);
        add(resultScrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void evaluarExpresion() {
        String expresion = expressionArea.getText();
        NodoArbol raiz = arbolExpresiones.construirArbol(expresion);

        String inorden = arbolExpresiones.imprime(raiz);
        String postorden = arbolExpresiones.imprimePos(raiz);
        String preorden = arbolExpresiones.imprimePre(raiz);

        String resultado = "El árbol en inorden es: " + inorden + "\n"
                         + "El árbol en postorden es: " + postorden + "\n"
                         + "El árbol en preorden es: " + preorden;

        resultArea.setText(resultado);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                ArbolExpresionesGUI gui = new ArbolExpresionesGUI();
                gui.setVisible(true);
            }
        });
    }
}
